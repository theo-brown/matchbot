# matchbot
Start dedicated servers for CS:GO matches from a web app or Discord